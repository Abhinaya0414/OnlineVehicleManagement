import { Component, OnInit } from '@angular/core';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.scss'],
  providers: [NgbCarouselConfig]
})
export class AuthComponent implements OnInit {

  showNavigationArrows = false;
  showNavigationIndicators = false;

  constructor(config: NgbCarouselConfig) {
    // customize default values of carousels
    config.interval = 5000;
    config.pauseOnHover = true;
  }
  ngOnInit(): void {
  }

}
