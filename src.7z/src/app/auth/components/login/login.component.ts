import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, AbstractControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/authService/auth.service';
import { setStorage, clearStorage } from 'src/app/util/shared';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  hide = true;
  loginForm!: FormGroup;
  submitted = false;
  invalidError = '';
  roleNames=["Admin","User"]
  roleId:any=[1,2];


  constructor(private formBuilder: FormBuilder, private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    clearStorage();
    this.loginForm = this.formBuilder.group(
      {
        userId: ['', [Validators.required]],
        role: ['', [Validators.required]],
        username: ['', [Validators.required]],
        password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(20)]]
      }
    );

    this.loginForm.valueChanges.subscribe(() => {
      this.invalidError = '';
    });
  }

  get f(): { [key: string]: AbstractControl } {
    return this.loginForm.controls;
  }

  onSubmit(): void {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    this.login(JSON.stringify(this.loginForm.value, null, 2));
  }

  login(reqObj: any) {
    this.authService.loginApi(reqObj).subscribe((response: any) => {
      console.log(response);
      if (response.userId != null) {
        console.log(response);
        
        let { userId, role,userName,token } = response;
        // setStorage('token', token);
        setStorage('userId', userId);
        setStorage('role', role);
        setStorage('username', userName);
        setStorage('token', token);
        // if (response.role == 1) 
        this.router.navigate(['layout/home']);
        // !!orgId && setStorage('orgId', orgId);
        // setStorage('userId', JSON.parse(reqObj).userId);
        // if (roleId === 3) this.router.navigate(['bank-admin']);
        // else this.router.navigate(['layout/home']);
      } 
    }, (error:any) => {
      console.log(error);
      this.invalidError = error.error.message;
    });
  }
}
