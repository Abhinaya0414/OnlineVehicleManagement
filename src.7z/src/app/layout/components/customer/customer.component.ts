import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { CustomerService } from 'src/app/services/customer/customer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit {

  allCustomers:any = [];
  active = 1;
  addCustomerForm!: FormGroup;
  onSubtmiBtn =false;
  addCustNextPage = false;
  updateButton = false;
  onSubmitBtnupdate = false;
  deleteButton = false;
  deleteCust = false;
  updateCustNextPage = false;
  customerData:any;
  modalOption: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
  };
  constructor(private modalService: NgbModal,private customerService : CustomerService,private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.getAllCustomers();
    this.addCustomerForm = this.formBuilder.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      username: ['', [Validators.required]],
      mobileNumber: ['', [Validators.required]],
      role: ['', [Validators.required]],
      password: ['',[Validators.required]],
      email: ['', [Validators.email, Validators.required]],
      address: ['',[Validators.required]]
    });
  }

  
  onSubmitAddCust(): void {
    this.onSubtmiBtn = true;
    if (this.addCustomerForm.invalid) {
      return;
    }
    this.addCustomer(this.addCustomerForm.value);
  }

  addCustomer(reqParam:any){
    
    console.log(reqParam);
    this.customerService.addCustomersApi(reqParam).subscribe((response: any) => {
      console.log(response);
      if(response.userId!=null){
        this.addCustNextPage=true;
      }
    }, (error:any) => {
      console.log(error);
    });   
  }

  get f(): { [key: string]: AbstractControl } {
    return this.addCustomerForm.controls;
  }

  getAllCustomers(){
    this.customerService.getAllCustomersApi().subscribe((response: any) => {
      console.log(response);
      this.allCustomers = response;
      // this.allCustomers = new MatTableDataSource(response);
    }, (error:any) => {
      console.log(error);
    });    
  }

  openModal(content: any) {
    this.modalService.open(content, this.modalOption);
  }

  updateButtonClicked(id:any){
    
    this.updateButton = true;
    this.customerService.getViewCustomerByIdApi(id).subscribe((response: any) => {
      console.log(response);
      if(response.userId!=null){
        // this.addCustomerForm.value.email = response.email;
        this.customerData = {...response};
        this.addCustomerForm.patchValue({
          firstName: response.firstName,
          lastName:response.lastName,
          email:response.email,
          role:response.role,
          address:response.address,
          password:response.password,
          mobileNumber : response.mobileNumber
        });
        
        
      }
    }, (error:any) => {
      console.log(error);
    }); 
  }

  updateSubmitBtn(){
    this.onSubtmiBtn = true;
    console.log(this.customerData);
    console.log(this.addCustomerForm.value);
    var updatedData = {...this.addCustomerForm.value};
    updatedData.userId = this.customerData.userId;
    this.updateCustomerAPI(updatedData);
    // if(JSON.stringify(this.customerData) == JSON.stringify(this.addCustomerForm.value)){
    //   console.log("MATCH");
    //   // throw error
    // }else{
    //   this.updateCustNextPage = true;
    //   console.log("API CALL");
    //   // call update api
    // }
  }

  // viewCustomerById(id:any){
  //   this.customerService.getViewCustomerByIdApi(id).subscribe((response: any) => {
  //     console.log(response);
  //     if(response.userId!=null){
  //       return response;
  //     }
  //   }, (error:any) => {
  //     console.log(error);
  //   });
  // }

  updateCustomerAPI(data:any){
    console.log(data)
    this.customerService.updateCustomerByIdApi(data).subscribe((response: any) => {
      console.log(response);
      if(response.userId!=null){
        this.updateCustNextPage = true;
      }
    }, (error:any) => {
      console.log(error);
    });
    
  }

  deleteCustomer(id:any){
       this.customerService.deleteByIdApi(id).subscribe((response: any) => {
      console.log(response);
      if(response == "Deleted Customer"){
        // this.deleteCust = true;
      }
    }, (error:any) => {
      console.log(error);
    });
  }

  windowReload(){
    window.location.reload();
  }



}

