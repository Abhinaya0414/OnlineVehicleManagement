import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BookingserviceService } from 'src/app/services/booking/bookingservice.service';
import { CustomerService } from 'src/app/services/customer/customer.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {

  allPayments:any;
  constructor(private modalService: NgbModal,private bookingService : BookingserviceService,private formBuilder: FormBuilder,
    private httpService: HttpClient,private customerService : CustomerService) { }

    ngOnInit(): void {
      this.getAllPayments();
    }

    getAllPayments(){
      this.bookingService.getAllPaymentsApi().subscribe((response: any) => {
        console.log(response);
        this.allPayments = response;
      }, (error:any) => {
        console.log(error);
      }); 
    }
}
