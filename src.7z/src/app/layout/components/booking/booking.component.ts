import { HttpClient } from '@angular/common/http';
import { ThisReceiver } from '@angular/compiler/public_api';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { BookingserviceService } from 'src/app/services/booking/bookingservice.service';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { HttpService } from 'src/app/services/httpService/http.service';
import { getStorage } from 'src/app/util/shared';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss']
})
export class BookingComponent implements OnInit {

  allBookings: any = [];
  active = 1;
  addBookingForm!: FormGroup;
  onSubtmiBtn = false;
  addCustNextPage = false;
  updateButton = false;
  onSubmitBtnupdate = false;
  deleteButton = false;
  deleteCust = false;
  updateCustNextPage = false;
  customerData: any;
  modalOption: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
  };
  bookingDateFilter: any;
  vehicleData: any;
  bookingStage: any = 1;
  onBookBtn = false;
  selectedVehicle: any;
  bookingDate: any;
  bookingData: any;
  selectedViewData: any;
  updateData:any;
  updateStage = 1;
  todaysDate:any;
  constructor(private modalService: NgbModal, private bookingService: BookingserviceService, private formBuilder: FormBuilder,
    private httpService: HttpClient, private customerService: CustomerService) { }
    userRole = getStorage('role') || 0;
    userId = getStorage('userId') || 0;

  ngOnInit(): void {
    var date = new Date();
    this.todaysDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000))
      .toISOString()
      .split("T")[0];

    this.getAllBookings();
    if(this.userRole == 1){
      this.addBookingForm = this.formBuilder.group({
        bookedTillDate: ['', [Validators.required]],
        bookingDescription: ['', [Validators.required]],
        customerId: new FormControl({value: ''}, Validators.required),
        distance: ['', [Validators.required]]
      });
    }
    if(this.userRole == 2){
      this.addBookingForm = this.formBuilder.group({
        bookedTillDate: ['', [Validators.required]],
        bookingDescription: ['', [Validators.required]],
        customerId: new FormControl({value: this.userId, disabled: true}, Validators.required),
        distance: ['', [Validators.required]]
      });
    }

    this.VehicleDataFromJson()
  }

  viewCustomerById(id: any) {
    this.customerService.getViewCustomerByIdApi(id).subscribe((response: any) => {
      console.log(response);
      if (response.userId != null) {
        this.customerData = response;
      }
    }, (error: any) => {
      console.log(error);
    });
  }



  updateSubmitBtn(){
var bookingObj = {
      "customer": this.updateData.customer,
      "vehicle": this.updateData.vehicle,
      "bookingId": this.updateData.bookingId,
      "bookingDate": this.updateData.bookingDate,
      "bookedTillDate": this.addBookingForm.value.bookedTillDate,
      "bookingDescription": this.addBookingForm.value.bookingDescription,
      "totalCost": this.updateData.totalCost,
      "distance": this.addBookingForm.value.distance,
    }
    this.bookingService.updateBookingApi(bookingObj).subscribe((response: any) => {
      console.log(response);
      if (response.bookingId != null) {
        this.updateStage = 2
      }
    }, (error: any) => {
      console.log(error);
    });
    console.log(bookingObj)
  }

  updateBtnClicked(data: any) {
    this.updateData = data;
    console.log(data)
    this.addBookingForm.patchValue({
      bookedTillDate: data.bookedTillDate,
      bookingDescription:data.bookingDescription,
      distance:data.distance,
      customerId:data.customer.userId
    });
  }

  bookSubmitBtn() {
    // this.viewCustomerById(this.addBookingForm.value.customerId);
    this.customerService.getViewCustomerByIdApi(this.userId).subscribe((response: any) => {
      console.log(response);
      if (response.userId != null) {
        this.customerData = response;
        var bookingObj = {
          "customer": this.customerData,
          "vehicle": this.selectedVehicle,
          "bookingId": 1000000,
          "bookingDate": this.bookingDate,
          "bookedTillDate": this.addBookingForm.value.bookedTillDate,
          "bookingDescription": this.addBookingForm.value.bookingDescription,
          "totalCost": this.selectedVehicle.chargesPerKM * this.addBookingForm.value.distance,
          "distance": this.addBookingForm.value.distance,
        }
        delete bookingObj.vehicle.image;
        console.log(bookingObj)
        this.bookingData = { ...bookingObj };
        this.addBooking(bookingObj);
      }
    }, (error: any) => {
      console.log(error);
    });
    // api call book
  }

  addBooking(data: any) {
    this.bookingService.addBookingApi(data).subscribe((response: any) => {
      console.log(response);
      if (response.bookingId != null) {
        this.bookingStage = 3
      }
    }, (error: any) => {
      console.log(error);
    });
  }

  viewData(item: any) {
    this.selectedViewData = item;
  }

  cancelBookingCall(data: any) {
    console.log(data);
    this.bookingService.cancelBookingApi(data).subscribe((response: any) => {
      console.log(response);
      if (response != null) {

      }
    }, (error: any) => {
      console.log(error);
    });
  }

  clickToPayment() {
    this.bookingStage = 4;
    this.bookingData.paymentDate = this.bookingDate
    this.bookingData.paymentMode = "Simulator"
    this.bookingData.paymentStatus = "Success"
    this.bookingData.paymentId = 1000000
    this.bookingService.addPaymentApi(this.bookingData).subscribe((response: any) => {
      console.log(response);
      if (response.paymentId != null) {

      }
    }, (error: any) => {
      console.log(error);
    });
  }

  vehicleSelected(item: any) {
    this.bookingStage = 2;
    var date = new Date();
    this.bookingDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000))
      .toISOString()
      .split("T")[0];
    this.selectedVehicle = item;
  }

  VehicleDataFromJson() {
    this.httpService.get('assets/vehicle.json')
      .subscribe((data: any) => {
        this.vehicleData = data
      });
  }

  bookinsByDate() {
    this.allBookings = {};
    this.bookingService.getAllBookingsByDateApi(this.bookingDateFilter).subscribe((response: any) => {
      console.log(response);
      this.allBookings = response;
    }, (error: any) => {
      console.log(error);
    });
  }

 
  get f(): { [key: string]: AbstractControl } {
    return this.addBookingForm.controls;
  }

  getAllBookings() {
    this.bookingService.getAllBookingsApi().subscribe((response: any) => {
      console.log(response);
      this.allBookings = response;
    }, (error: any) => {
      console.log(error);
    });
  }

  openModal(content: any) {
    this.modalService.open(content, this.modalOption);
  }

    windowReload() {
    window.location.reload();
  }




}
