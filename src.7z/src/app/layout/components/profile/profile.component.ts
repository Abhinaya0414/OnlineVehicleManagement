import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/services/customer/customer.service';
import { getStorage } from 'src/app/util/shared';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  userID = getStorage('userId') || 0;
  profileData:any;
  constructor(private customerService : CustomerService) { }

  ngOnInit(): void {
    this.getProfile()
  }

  getProfile(){
    this.customerService.getViewCustomerByIdApi(this.userID).subscribe((response: any) => {
      console.log(response);
      if(response.userId!=null){
        this.profileData = {...response};
        console.log(this.profileData)
        console.log(this.profileData.username)
      }
    }, (error:any) => {
      console.log(error);
    }); 
  }
}
