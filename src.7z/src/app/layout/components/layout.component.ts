import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { getStorage,  setStorage } from 'src/app/util/shared';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MediaMatcher } from '@angular/cdk/layout';
import { DataService } from 'src/app/services/dataService/data.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {

  mobileQuery!: MediaQueryList;
  isExpanded = true;
  mobileScreen = false;
  onboardingCompleted = false;
  username = "";
  showDropdown = true;

  startDate!: any;
  endDate!: any;
  selectedSortOrder = 'Month';
  todayDate = new Date();
  selected = 'option2';
  
  userRole = getStorage('role') || 0;
  lastActive: any;

  private _mobileQueryListener!: () => void;
  constructor(private changeDetectorRef: ChangeDetectorRef, private media: MediaMatcher, private modalService: NgbModal,
    private router: Router, private activatedRoute: ActivatedRoute, private dataService: DataService) {
    router.events.subscribe(val => {
      if (val instanceof NavigationEnd) this.showDropdown = (val.url == '/layout/home');
    });
  }

  ngOnInit(): void {
}

  logout(){
    localStorage.clear();
    window.location.reload();
  }
}
