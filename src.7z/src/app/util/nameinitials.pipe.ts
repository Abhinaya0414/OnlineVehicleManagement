import {
    Pipe,
    PipeTransform
} from '@angular/core';

@Pipe({
    name: 'Initials'
})

export class NameinitialsPipe implements PipeTransform {
    transform(name: any) {
        return name.match(/(\b\S)?/g).join("").match(/(^\S|\S$)?/g).join("").toUpperCase();
    }
} 