import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'appFilter' })
export class FilterPipe implements PipeTransform {
    transform(items: any[], searchText: string, category: string = ''): any[] {
        if (!items) return [];

        if (!searchText && !category) return items;

        if (category) {
            if (category == 'Filter') items;
            else {
                items = items.filter((it) => {
                    return it.category?.includes(category);
                });
            }
        }

        if (!searchText) return items;
        searchText = searchText.toLocaleLowerCase();

        return items.filter((it) => {
            return it.payeeName?.toLocaleLowerCase().includes(searchText) || it.category?.toLocaleLowerCase().includes(searchText) || it.gstOrPan?.toLocaleLowerCase().includes(searchText);
        });
    }
}

@Pipe({ name: 'tableFilter' })
export class TablePipe implements PipeTransform {
    transform(items: any[], searchText: string): any[] {
        if (!items) return [];

        if (!searchText) return items;
        searchText = searchText.toLocaleLowerCase();

        return items.filter((it) => {
            return it.name?.toLocaleLowerCase().includes(searchText) || it.doneBy?.toLocaleLowerCase().includes(searchText) || it.amount?.toString().toLocaleLowerCase().includes(searchText)
            || it.appvRejectBy?.toLocaleLowerCase().includes(searchText) || it.batchName?.toLocaleLowerCase().includes(searchText) || it.status?.toLocaleLowerCase().includes(searchText);
        });
    }
}

@Pipe({ name: 'bankFilter' })
export class BankTablePipe implements PipeTransform {
    transform(items: any[], searchText: string): any[] {
        if (!items) return [];

        if (!searchText) return items;

        searchText = searchText.toLocaleLowerCase();

        return items.filter((it) => {
            return it.orgName?.toLocaleLowerCase().includes(searchText) || it.accountNumber?.toLocaleLowerCase().includes(searchText) || it.orgGstinNo?.toLocaleLowerCase().includes(searchText) ||
                it.payeeGstinName?.toLocaleLowerCase().includes(searchText) || it.payeegstOrPan?.toLocaleLowerCase().includes(searchText);
        });
    }
}