
export const setStorage = (key: any, value: any) => {
    localStorage.setItem(key, value);
}

export const getStorage = (key: any) => {
    return localStorage.getItem(key);
}

export const clearStorage = () => {
    return localStorage.clear();
}
