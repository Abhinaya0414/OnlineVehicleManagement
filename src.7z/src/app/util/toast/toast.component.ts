import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { DataService } from 'src/app/services/dataService/data.service';

@Component({
  selector: 'app-toast',
  templateUrl: './toast.component.html',
  styleUrls: ['./toast.component.scss']
})
export class ToastComponent implements OnInit {

  show = false;
  message: string = "";
  type: string = '';
  duration = 5;
  notificationSubscription!: Subscription;

  constructor(private dataService: DataService) { }

  ngOnInit(): void {
    this.notificationSubscription = this.dataService.snackbarState.subscribe(
      (state) => {
        this.type = state.type;
        this.message = state.message;
        this.show = state.show;
        this.duration = state.duration;

        setTimeout(() => {
          this.show = false;
        }, this.duration * 1000);
      });
  }

  ngOnDestroy() {
    this.notificationSubscription.unsubscribe();
  }
}
