import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpService } from '../httpService/http.service';

@Injectable({
  providedIn: 'root'
})
export class BookingserviceService {

  BaseUrl = environment.baseUrl;

  constructor(private httpService: HttpService) { }

  getAllBookingsApi() {
    return this.httpService.authGet(this.BaseUrl + "booking/viewListOfBookings",  true);
  }

  getAllBookingsByDateApi(date:any) {
    return this.httpService.authGet(this.BaseUrl + "booking/viewAllBookingByDate/"+date,  true);
  }

  addBookingApi(data:any) {
    return this.httpService.authPost(this.BaseUrl + "booking/addBooking", data, true);
  }

  addPaymentApi(data:any) {
    return this.httpService.authPost(this.BaseUrl + "payment/addPayment", data, true);
  }

  cancelBookingApi(data:any) {
    return this.httpService.authPost(this.BaseUrl + "booking/cancelBooking", data, true);
  }

  getAllPaymentsApi() {
    return this.httpService.authGet(this.BaseUrl + "payment/viewAllPayments", true);
  }

  updateBookingApi(data:any) {
    return this.httpService.authPost(this.BaseUrl + "booking/updateBooking", data, true);
  }
}
