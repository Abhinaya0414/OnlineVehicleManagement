import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpService } from '../httpService/http.service';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  BaseUrl = environment.baseUrl;

  constructor(private httpService: HttpService) { }

  getAllCustomersApi() {
    return this.httpService.authGet(this.BaseUrl + "customer/getAllCustomer",  true);
  }

  addCustomersApi(data:any) {
    return this.httpService.authPost(this.BaseUrl + "customer/addCustomer", data, true);
  }

  getViewCustomerByIdApi(id:any) {
    return this.httpService.authGet(this.BaseUrl + "customer/viewCustomerById/"+id,  true);
  }

  updateCustomerByIdApi(data:any) {
    return this.httpService.authPost(this.BaseUrl + "customer/updateCustomer",data,  true);
  }

  deleteByIdApi(id:any) {
    return this.httpService.authGet(this.BaseUrl + "customer/deleteCustomer/"+id,  true);
  }
}
