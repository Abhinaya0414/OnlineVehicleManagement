import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpService } from '../httpService/http.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  BaseUrl = environment.baseUrl;

  constructor(private httpService: HttpService) { }

  loginApi(data: any) {
    return this.httpService.authPost(this.BaseUrl + "user/validate", data, true);
  }
}
