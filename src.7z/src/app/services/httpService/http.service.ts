import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { getStorage } from 'src/app/util/shared';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  constructor(private httpClient: HttpClient) { }
  token = getStorage('token') || 0;

  authPost(url: string, data: any, isLoaderEnable: boolean) {
    let options = new HttpHeaders({ "Content-Type": "application/json","Authorization":"Bearer : "+this.token });
    return this.httpClient.post(url, data, { headers: options })
  }

  authGet(url: string, isLoaderEnable: boolean) {
    let options = new HttpHeaders({ "Content-Type": "application/json","Authorization":"Bearer : "+this.token });
    return this.httpClient.get(url, { headers: options })
  }

  authPut(url: string, data: any, isLoaderEnable: boolean) {
    let options = new HttpHeaders({ "Content-Type": "application/json","Authorization":"Bearer : "+this.token });
    return this.httpClient.put(url, data)
  }

}
